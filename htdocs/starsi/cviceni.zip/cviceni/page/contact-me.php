<h1>This is contact page</h1>
This page is included in the index.php